﻿void Main()
{
    string str = "AscVVbgSl";
    System.Console.WriteLine(str);
    str = str.ToLower();
    System.Console.WriteLine(str);
}
Main();